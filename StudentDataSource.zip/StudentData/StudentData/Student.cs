﻿using System.IO;
using System.Linq;
using System.Text;

namespace StudentData
{
    class Student
    {
        public int StudentID;
        public string StudentFName;
        public string StudentLName;
        public string StudentEmail;
        public int StudentHeight;
        public int StudentWeight;
        public string DegreeLevel;
        public string DegreeType;
   

        public void Enter( string fName, string lName, string email, int h, int w, string degLevel, string degType )
        {
            /*
            string szConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='StudentDB.xlsx';Extended Properties='Excel 12.0;HDR=YES;'";
            oleDBcnn = new OleDbConnection(szConnectionString);
            oleDBcnn.Open();
            objDA = new System.Data.OleDb.OleDbDataAdapter("select * from [Students$]", oleDBcnn);
            DataSet excelDataSet = new DataSet();
            objDA.Fill(excelDataSet);
            int numRecords = excelDataSet.Tables[0].Rows.Count;
            oleDBCmd = new OleDbCommand();
            oleDBCmd.Connection = oleDBcnn;
            StudentID = numRecords + 1;
            oleDBCmd.CommandText = @"Insert into [Students$] VALUES (" + StudentID + ",'" + fName + "', '" + lName + "', " + (int)h + "," + (int)w + ",'" + degLevel + "', '" + degType + "')";


            oleDBCmd.ExecuteNonQuery();
            objDA.Update(excelDataSet);
            oleDBcnn.Close();
            */
            FileInfo fiStudentDB = new FileInfo("StudentDB.csv");
            // MessageBox.Show(File.ReadAllLines(fiStudentDB.ToString()).Count().ToString());
            StudentID = File.ReadAllLines(fiStudentDB.ToString()).Count();
            StringBuilder sbRecord = new StringBuilder();
            sbRecord.Append(StudentID + ",");
            sbRecord.Append(fName + ",");
            sbRecord.Append( lName + ",");
            sbRecord.Append(email + ",");
            sbRecord.Append( h.ToString() + ",");
            sbRecord.Append(w.ToString() + ",");
            sbRecord.Append(degLevel.ToString() + ",");
            sbRecord.AppendLine(degType);
            File.AppendAllText(fiStudentDB.ToString(), sbRecord.ToString());
        }
    }
}
