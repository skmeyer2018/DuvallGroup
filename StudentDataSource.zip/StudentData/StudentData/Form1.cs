﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Text.RegularExpressions;
//using Microsoft.Office.Interop;

namespace StudentData
{
    public partial class Form1 : Form
    {
       // public OleDbConnection oleDBcnn;
     //   public OleDbDataAdapter objDA;
     //   public OleDbCommand oleDBCmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           // Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            // xlApp.GetOpenFilename()
            /*
            string szConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='StudentDB.xlsx';Extended Properties='Excel 12.0;HDR=YES;'";
            oleDBcnn = new OleDbConnection(szConnectionString);
            oleDBcnn.Open();
            objDA = new System.Data.OleDb.OleDbDataAdapter("select * from [Students$]", oleDBcnn);
            DataSet excelDataSet = new DataSet();
            objDA.Fill(excelDataSet);
  
            oleDBcnn.Close();
            */
            // excelDataSet.Tables[0]

        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            DialogResult dlgEnter = MessageBox.Show( "Are you sure you want to enter your data?","OK to Enter?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlgEnter == DialogResult.Yes)
            {
                Student newStudent = new Student();
                newStudent.StudentFName = txtFName.Text;
                newStudent.StudentLName = txtLName.Text;
                if (newStudent.StudentFName.Trim() == "" || newStudent.StudentFName.Trim() == "")
                {
                    MessageBox.Show("Please enter legitimate data for your name!", "NAME INPUT UNACCEPTABLE!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                
                newStudent.StudentEmail = txtStudentEmail.Text;
                Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match = regex.Match(newStudent.StudentEmail);
                if (!match.Success || newStudent.StudentEmail.Trim() == "")
                {
                    MessageBox.Show("Please enter a valid email address in a form like abc@email.com", "INVALID EMAIL INPUT!",  MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                newStudent.StudentHeight = (int)numHeight.Value;
                newStudent.StudentWeight = (int)numWeight.Value;
                newStudent.DegreeLevel = cmbLevel.Text;
                newStudent.DegreeType = cmbType.Text;
                newStudent.Enter(newStudent.StudentFName, newStudent.StudentLName, newStudent.StudentEmail, newStudent.StudentHeight, newStudent.StudentWeight, newStudent.DegreeLevel, newStudent.DegreeType);
                MessageBox.Show(newStudent.StudentFName + ", thank you for your input.  Your student id is " + newStudent.StudentID.ToString());
                
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFName.Clear();
            txtLName.Clear();
            txtStudentEmail.Clear();
            numHeight.Value = 1;
            numWeight.Value = 1;
            cmbLevel.Text = "";
            cmbType.Text = "";

        }
    }
}
